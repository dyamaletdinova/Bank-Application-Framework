package ccard.model;

import finCo.model.FincoData;

public class CCardData extends FincoData {
private String expDate;

public String getExpDate() {
	return expDate;
}

public void setExpDate(String expDate) {
	this.expDate = expDate;
}

}
