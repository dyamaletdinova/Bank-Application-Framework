/**
 * 
 */
package finCo.model;

/**
 *
 * @author Diana Yamaletdinova
 * Feb 6, 2017
 */
public interface IReport {
	//void generateReport(Functor<Account,String> functor);
	void generateReport();
}
