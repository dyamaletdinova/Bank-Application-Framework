/**
 * 
 */
package finCo.model;



/**
 *
 * @author Diana Yamaletdinova
 * Feb 8, 2017
 */
public interface FinCoObserver {
	public void update(String s);
}
