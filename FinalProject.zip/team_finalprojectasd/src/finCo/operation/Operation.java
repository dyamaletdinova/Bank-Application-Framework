/**
 * 
 */
package finCo.operation;

/**
 *
 * @author Diana Yamaletdinova
 * Feb 6, 2017
 */
public interface Operation {
	void execute();
}
