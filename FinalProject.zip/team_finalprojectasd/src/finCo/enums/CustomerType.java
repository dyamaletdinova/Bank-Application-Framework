/**
 * 
 */
package finCo.enums;

/**
 *
 * @author Diana Yamaletdinova
 * Feb 6, 2017
 */
public enum CustomerType {
	PERSON,
	ORGANIZATION
}
